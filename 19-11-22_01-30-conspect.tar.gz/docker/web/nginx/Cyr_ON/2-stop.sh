docker stop a-nginx
docker rm a-nginx


