 docker build -t  eas1804/nginx_files_pass  .
