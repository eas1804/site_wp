docker run --name nginx_iso \
-v  /root/docker_app/iso_passwd/iso/:/usr/share/nginx/html:ro \
-p 8085:80 \
-d eas1804/nginx_files_pass 

