 docker run --name my-nginx \
-v /home/conspect:/usr/share/nginx/html:ro \
-p 8084:80 \
-d nginx 

